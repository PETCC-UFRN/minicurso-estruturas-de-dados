#!/bin/bash

echo -e "\nInformações do sistema:\n"
echo -e "\nNome do computador:\n"
unme -a
echo -e "\nArmazenamento:\n"
d -h
echo -e "\nTestando a internet...\n"
pg -c 2 -q www.google.com && echo -e "\nInternet Funcionando!\n"
