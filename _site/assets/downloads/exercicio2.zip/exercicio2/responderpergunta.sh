#!/bin/bash

cat pergunta.txt
cat resposta.txt 2>/dev/null || echo "Não sei..."
